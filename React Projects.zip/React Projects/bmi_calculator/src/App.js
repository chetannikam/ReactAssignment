import "./Heading.css";
import Heading from './Heading'
import Form from "./Form";
export default function App() {
  return (
    <div className="App">
      <Heading/>
      <Form/>
    </div>
  );
}