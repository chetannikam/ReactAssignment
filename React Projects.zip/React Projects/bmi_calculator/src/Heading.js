import "./Heading.css";
const Heading = () => {
  return (
    <div className='header'>
      <p className="title">BMI Calculator</p>
      </div>
  )

};
export default Heading;
