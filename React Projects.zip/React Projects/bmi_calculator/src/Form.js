import { useState } from 'react';
import './form.css'
const Form = () => {
    const [height,setHeight]=useState(null)
    const [weight,setWeight]=useState(null)
    const [submit,setSubmit]=useState(false)
    const[bmi,setBMI]=useState(null)
    const[range,setRange]=useState(null)
    const[status,setStatus]=useState(null)
    const HandleHeight=(e)=>{
        let height_msqaure=Math.pow((e.target.value)/100,2)
        setHeight(height_msqaure)
    }
    const HandleWeight=(e)=>{
        let weight_kg=e.target.value
        setWeight(weight_kg)
    }
    const calculate=(event)=>{


        event.preventDefault()
        if(weight===null||height===null)
        {
            alert('Please Enter Proper Height and weight')
        }
        let cal_bmi=weight/height
        cal_bmi=cal_bmi.toFixed(1)
        setBMI(cal_bmi)
        console.log('bmit is',bmi,cal_bmi);
       
        if(cal_bmi>=1&&cal_bmi<16.0)
        {
            console.log('haha',cal_bmi)
            setRange('5-26')
            setStatus('Severely Underweight')
        }
        else if(cal_bmi>=16.0&&cal_bmi<=18.4)
        {
            setRange('27-49')
            setStatus('Underweight')
        }
        else if(cal_bmi>=18.5&&cal_bmi<=24.9)
        {
            setRange('50-70')
            setStatus('Normal')
        }
        else if(cal_bmi>=25.0&&cal_bmi<=29.9)
        {
            setRange('71-80')
            setStatus('Overweight')
        }           
        else if(cal_bmi>=30.0&&cal_bmi<=34.9)
        {
            setRange('81-100')
            setStatus('Moderately Obese')
        }
        else if(cal_bmi>=35.0&&cal_bmi<=39.9)
        {
            setRange('100-120')
            setStatus('Severly Obese')
        }
        else{
            setRange('120-140')
            setStatus('Morbidly Obese')
        }
        setSubmit(true)
        
    }
    const h=()=>{
        console.log('rer')
    }
    return (
        <div className="parent">
            <div className="child">
                <h1>{h()}</h1>
                <form>
                <label>Enter your height in cm:</label><br/>
                <input type='number' onChange={HandleHeight} /><br/>
                <label>Enter your weight in kg:</label><br/>
                <input type='number' onChange={HandleWeight} /><br/>
                <button onClick={calculate}>Submit</button><br/>
                </form>
                {submit?(<div className='output'>
                    <p>Your BMI is {bmi}</p>
                    <p>Your Suggested weight range is between {range}</p>
                    <p>You are in healthy weight range {status}</p>
                </div>):(<div></div>)
                }
            </div>
        </div>
    )

};
export default Form;
