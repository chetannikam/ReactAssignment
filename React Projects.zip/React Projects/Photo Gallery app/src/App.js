import "./App.css";
import Gallery from "./components/Gallery";

function App() {
  return (
    <>
      <div className="main_container">
        <h1>Welcome to my photo Gellery </h1>
        <Gallery />
      </div>
    </>
  );
}

export default App;
