const Products=[
    {
        image:'https://cdn.pixabay.com/photo/2017/01/13/04/56/blank-1976334_960_720.png',
        title:'Cotton Shirt',
        description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        price:'Rs.250',
        total:'Rs.300'
    },
    {
        image:'https://cdn.pixabay.com/photo/2016/11/23/06/57/isolated-t-shirt-1852114_960_720.png',
        title:'Green Shirt',
        description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        price:'Rs.550',
        total:'Rs.600'
    },
    {
        image:'https://cdn.pixabay.com/photo/2016/11/23/06/57/isolated-t-shirt-1852113_960_720.png',
        title:'Full Sleeve Tshirt',
        description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        price:'Rs.200',
        total:'Rs.250'
    }

]
export default Products;