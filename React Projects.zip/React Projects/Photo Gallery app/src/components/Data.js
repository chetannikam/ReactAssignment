const GelleryImages = [
  {
    id: 1,
    image:
      "https://images.pexels.com/photos/1151282/pexels-photo-1151282.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: "Vivian Maier",
  },

  {
    id: 2,
    image:
      "https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: "Elliott Erwitt",
  },

  {
    id: 3,
    image:
      "https://images.pexels.com/photos/2101187/pexels-photo-2101187.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: " Steve McCurry",
  },

  {
    id: 4,
    image:
      "https://images.pexels.com/photos/3347244/pexels-photo-3347244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: "Ansel Adams",
  },

  {
    id: 5,
    image:
      "https://images.pexels.com/photos/2434202/pexels-photo-2434202.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",

    by: "jordan albo",
  },
  {
    id: 6,
    image:
      "https://images.pexels.com/photos/5701925/pexels-photo-5701925.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: "Robert Frank",
  },

  {
    id: 7,
    image:
      "https://images.pexels.com/photos/4385849/pexels-photo-4385849.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    by: "Gary Winogrand",
  },
];

export default GelleryImages;
